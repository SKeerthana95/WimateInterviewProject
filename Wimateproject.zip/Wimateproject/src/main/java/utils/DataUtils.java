package utils;

import java.io.IOException;

import org.testng.annotations.DataProvider;

import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import utilss.ReadExcel;

public class DataUtils {
	@DataProvider(name = "login")
	public String[][] getData() throws RowsExceededException, BiffException, WriteException, IOException{
		String[][] excelData = ReadExcel.getExcelLoginData();		
		return excelData;			
	}
		
	@DataProvider(name = "Signup")
	public String[][]getSignupdata(){
		String[][] excelData = ReadExcel.getExcelSignupData();
		return excelData;		
	}
}
