package utilss;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ExcelUtils {

    private static Workbook workbook;
    private static Sheet sheet;
    private static FileInputStream fis;
    private static FileOutputStream fos;

    public static void setExcelFile(String path, String sheetName) throws IOException {
        fis = new FileInputStream("./test-data/Signup-data.xlsx");
        workbook = new XSSFWorkbook(fis);
        sheet = workbook.getSheetAt(1);
        System.out.println(sheet.getSheetName());
    }


  
	@SuppressWarnings("deprecation")
	public static String getCellData(int rowNum, int colNum) {
        Cell cell = sheet.getRow(rowNum).getCell(colNum);
        cell.setCellType(CellType.STRING);
        return cell.getStringCellValue();
    }

    public static void setCellData(String path, String result, int rowNum, int colNum) throws IOException {
        Row row = sheet.getRow(rowNum);
        Cell cell = row.createCell(colNum);
        cell.setCellValue(result);
        fos = new FileOutputStream(path);
        workbook.write(fos);
        fos.close();
    }

    public static int getRowCount() {
        return sheet.getLastRowNum();
    }

    public static void closeExcel() throws IOException {
        fis.close();
        workbook.close();
    }
}
