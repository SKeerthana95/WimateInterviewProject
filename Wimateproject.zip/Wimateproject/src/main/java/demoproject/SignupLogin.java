package demoproject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.DataUtils;
import utilss.ExcelUtils;


public class SignupLogin{
	  WebDriver driver;
	  String excelPath = "D:\\JAVA\\keerthana\\Wimateproject\\test-data\\Signup-data.xlsx";
	  String sheetName = "Sheet2";
	
@BeforeClass
	public void setup() {
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\bhara\\Downloads\\geckodriver-v0.34.0-win64\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.get("https://e2e.cloudtesla.com/");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);		
	}
//@Test(dataProvider = "Signup", dataProviderClass = DataUtils.class, priority =1 )
	public void signtest(String data[]) throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//a[text()='Sign up']")).click();
		Thread.sleep(3000);
		String expectedURL = "https://e2e.cloudtesla.com/authentication/signup";
        driver.get(expectedURL);
        String actualURL = driver.getCurrentUrl();
        Assert.assertEquals(actualURL, expectedURL, "The current URL is not as expected.");
        System.out.println(actualURL);

        Thread.sleep(3000);
        WebElement ele = driver.findElement(By.id("password"));
        ele.sendKeys(data[6]);
        driver.findElement(By.id("firstName")).sendKeys(data[0]);
        driver.findElement(By.id("lastName")).sendKeys(data[1]);
        driver.findElement(By.id("mobile")).sendKeys(data[2]);
        driver.findElement(By.id("email")).sendKeys(data[3]);
        driver.findElement(By.id("username")).sendKeys(data[4]);
        driver.findElement(By.id("desc")).sendKeys(data[5]);       
       
        driver.findElement(By.xpath("//button[text()='Sign up']")).click();
        Thread.sleep(3000);
        String expectedURL1 = "https://e2e.cloudtesla.com/dashboards/create";
        driver.get(expectedURL1);
        String actualURL1 = driver.getCurrentUrl();
        Assert.assertEquals(actualURL1, expectedURL1, "The current URL is not as expected."); 
        System.out.println(actualURL1);
        Thread.sleep(3000);        
 } 
@Test(dataProvider = "loginData",priority = 2)
public void loginTest(String username, String password, int rowNum) throws IOException, InterruptedException {
    driver.get("https://e2e.cloudtesla.com/");
    Thread.sleep(2000);

    // Perform login
    WebElement usernameField = driver.findElement(By.xpath("//input[@name='username']")); 
    WebElement passwordField = driver.findElement(By.id("password")); 
    WebElement loginButton = driver.findElement(By.xpath("//button[text()='Sign in']")); 

    usernameField.sendKeys(username);
    Thread.sleep(2000);
    passwordField.sendKeys(password);
    Thread.sleep(2000);
    loginButton.click();
    Thread.sleep(2000);

    // Verify the URL after login
    String expectedURL = "https://e2e.cloudtesla.com/dashboards/create";
    String actualURL = driver.getCurrentUrl();

    // Write the result to the Excel sheet
    if (actualURL.equals(expectedURL)) {
        ExcelUtils.setCellData(excelPath, "Pass", rowNum, 2);

        // Perform sign out if login is successful
        WebElement profileButton = driver.findElement(By.className("caret"));
        profileButton.click();
        WebElement signOutButton = driver.findElement(By.xpath("//a[text()='Signout']")); 
        signOutButton.click();
        Thread.sleep(3000);
        
    } else {
        ExcelUtils.setCellData(excelPath, "Fail", rowNum, 2);
    }

    // Assert the URL to ensure the test fails in case of an incorrect URL
//    Assert.assertEquals(actualURL, expectedURL, "The current URL is not as expected.");
}

@DataProvider(name = "loginData")
public Object[][] getData() throws IOException {
    ExcelUtils.setExcelFile("./test-data/Signup-data.xlsx", sheetName);
    int rowCount = ExcelUtils.getRowCount();
    System.out.println("rowCount :"+ rowCount);
    Object[][] data = new Object[rowCount][3];

    for (int i = 1; i <= rowCount; i++) {
    	System.out.println(i);
        data[i - 1][0] = ExcelUtils.getCellData(i, 0); // username
        System.out.println(data[i - 1][0]);
        data[i - 1][1] = ExcelUtils.getCellData(i, 1); // password
        System.out.println(data[i - 1][1]);
        data[i - 1][2] = i; // row number
    }
    

    return data;
}
@AfterClass
public void tearDown() throws IOException {
    ExcelUtils.closeExcel();
    if (driver != null) {
        driver.quit();
    }
}



}
